const display = document.getElementById('display');

function appendToDisplay(value) {
    display.textContent += value;
}

function clearDisplay() {
    display.textContent = '';
}

function deleteLast() {
    display.textContent = display.textContent.slice(0, -1);
}

function calculateResult() {
    try {
        const result = eval(display.textContent);
        display.textContent = result;
    } catch (error) {
        display.textContent = 'Error';
    }
}

document.addEventListener('keydown', function(event) {
    const key = event.key;

    if (/[\d\.+\-*/%]/.test(key) || key === 'Backspace' || key === 'Enter' || key === '=') {
        event.preventDefault();

        switch (key) {
            case 'Enter':
            case '=':
                calculateResult();
                break;
            case 'Backspace':
                deleteLast();
                break;
            default:
                appendToDisplay(key);
                break;
        }
    }
});
