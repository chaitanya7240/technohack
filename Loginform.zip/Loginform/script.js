function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Hardcoded credentials for demonstration (should be replaced with secure authentication)
    if (username === "Admin" && password === "Admin1") {
        document.getElementById("loginMessage").textContent = "Login successful!";
        document.getElementById("loginMessage").classList.add("success"); // Apply success class
        // Optionally redirect or perform other actions after successful login
    } else {
        document.getElementById("loginMessage").textContent = "Login failed: Invalid username or password";
        document.getElementById("loginMessage").classList.remove("success"); // Remove success class
    }
}
